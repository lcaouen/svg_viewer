# svg_viewer
This is a web based viewer for the EPICS Archiver Appliance that uses SVG instead of Canvas with the potential to use WebGL in the future. 

